<?php

declare(strict_types=1);

namespace Admin\Controller;

use Admin\Controller\AppController;

class ManagePagesController extends AppController
{

    public function managePage($id = null)
    {
        $this->viewBuilder()->setLayout('content');
        $this->set("page_title", ['0' => 'CMS', '1' => 'Manage Page']);

        $CmsPages = $this->fetchTable('CmsPages');
        $cmsPage = $CmsPages->get($id);

        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->getData();
            $cmsPage = $CmsPages->patchEntity($cmsPage, $data);
            if ($CmsPages->save($cmsPage)) {
                $this->Flash->success(__('The page has been saved.'));

                return $this->redirect(['action' => 'listing']);
            }
            $this->Flash->error(__('The page could not be saved. Please, try again.'));
        }

        $this->set(compact('cmsPage'));
        $this->render("manage_page");
    }

    public function sectionListing($id = '')
    {
        $this->viewBuilder()->setLayout('content');
        $this->set("page_title", ['0' => 'Manage Pages', '1' => 'List Sections']);

        $pageId = $id ?: $this->request->getQuery('page_id');

        $CmsPages = $this->fetchTable('CmsPages');
        $CmsContents = $this->fetchTable('CmsContents');

        $cmsPage = $CmsPages->get($pageId);

        $query = $CmsContents->find()
            ->select([
                'CmsContents.id',
                'CmsContents.name',
                'CmsContents.code',
                'CmsContents.page_id',
                'category_name' => 'CmsContentCategories.name',
                'category_code' => 'CmsContentCategories.code'
            ])
            ->leftJoin(
                ['CmsContentCategories' => 'cms_content_categories'],
                ['CmsContentCategories.id = CmsContents.content_category_id']
            )
            ->where(['CmsContents.parent_id' => 0]);

        if (!empty($pageId)) {
            $query->where(['CmsContents.page_id' => $pageId]);
        }

        $this->paginate = [
            'limit' => 20,
            'order' => [
                'CmsContentCategories.id' => 'ASC',
                'CmsContents.id' => 'ASC'
            ]
        ];

        $sections = $this->paginate($query);

        $this->set(compact('sections', 'pageId', 'cmsPage'));
        $this->render("section_listing");
    }

    public function sectionAddEdit($pageId = null, $id = null)
{
    $this->viewBuilder()->setLayout('content');
    $this->set("page_title", ['0' => 'Manage Pages', '1' => $id ? 'Edit Section' : 'Add Section']);

     $CmsPages = $this->fetchTable('CmsPages');
     $cmsPage = $CmsPages->get($pageId);

    $CmsContents = $this->fetchTable('CmsContents');
    $CmsContentCategories = $this->fetchTable('CmsContentCategories');
    $contentCategories = $CmsContentCategories->find('list')->toArray();

    if ($id) {
        $section = $CmsContents->get($id);
    } else {
        $section = $CmsContents->newEmptyEntity();
    }

    // Always set page_id from URL parameter
    if ($pageId) {
        $section->page_id = $pageId;
    }

    if ($this->request->is(['post', 'put'])) {
        $data = $this->request->getData();

        // Force page_id into data before save
        if ($pageId) {
            $data['page_id'] = $pageId;
        }

        $section = $CmsContents->patchEntity($section, $data);

        if ($CmsContents->save($section)) {
            $this->Flash->success(__('The section has been saved.'));

            return $this->redirect([
                'action' => 'sectionListing',$pageId
                
            ]);
        }

        $this->Flash->error(__('The section could not be saved. Please, try again.'));
    }

    $this->set(compact('section', 'contentCategories', 'pageId', 'cmsPage'));
    $this->render("section_add_edit");
}
public function sectionDelete($pageId = null, $id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $CmsContents = $this->fetchTable('CmsContents');
        $section = $CmsContents->get($id);
        $pageId = $section->page_id;

        if ($CmsContents->delete($section)) {
            $this->Flash->success(__('The section has been deleted.'));
        } else {
            $this->Flash->error(__('The section could not be deleted. Please, try again.'));
        }

        return $this->redirect([
            'action' => 'sectionListing',
            '?' => ['page_id' => $pageId]
        ]);
    }   
}
