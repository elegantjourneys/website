<div class="container">
    <div class="page-inner">
        <div class="page-header">

            <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                    <a href="#">
                        <i class="icon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <?= $this->Html->link(
                        $page_title[0] ?? '',
                        ['plugin' => 'Admin', 'controller' => 'ManagePages', 'action' => 'sectionListing', $pageId]
                    ); ?>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="#"><?= @$page_title["1"] ?></a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <?= $this->Form->create($section) ?>
                <div class="card">
                    <div class="card-header">
                        
                        <div class="page-header-box">
                            <div class="d-flex flex-column flex-md-row align-items-md-center gap-2">

                                <!-- Left: Title -->
                                <h4 class="card-title text-white mb-0">
                                    <?= @$page_title["1"] ?>
                                </h4>

                                <!-- Middle: Page Name -->
                                <span class="page-name ms-md-auto">
                                    <?= $cmsPage->name ?>
                                </span>

                               

                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12 col-lg-12">
                                <div class="form-group">
                                    <label for="title">Name</label>
                                    <?= $this->Form->control('name', [
                                        'label' => false,
                                        'class' => 'form-control',
                                        'value' => $section->name ?? ''
                                    ]) ?>
                                </div>
                                <div class="form-group">
                                    <label for="description">Code</label>
                                    <?= $this->Form->control('code', [
                                        'label' => false,
                                        'class' => 'form-control',
                                        'value' => $section->code ?? ''
                                    ]) ?>
                                </div>
                                <div class="form-group">
                                    <label for="description">Type</label>
                                    <?= $this->Form->control('content_category_id', [
                                        'label' => false,
                                        'options' => $contentCategories,
                                        'class' => 'form-control',
                                        'value' => $section->content_category_id ?? ''
                                    ]) ?>
                                    <?= $this->Form->control('page_id', [
                                        'type' => 'hidden',
                                        'value' => $pageId
                                    ]); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-action">
                        <button type="submit" class="btn btn-success">Submit</button>
                    </div>
                </div>
                <?= $this->Form->end() ?>
            </div>
        </div>
    </div>
</div>